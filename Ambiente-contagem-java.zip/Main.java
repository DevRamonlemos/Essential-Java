import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("informe a quantidade de numeros a serem avaliados");
    int N = sc.nextInt();
    int cont=0;
    for(int i=0;i<N;i++){
      System.out.println("informe um numero inteiro");
      int numero = sc.nextInt();
      if(numero >=0){
        cont = cont+1;
      }else{
        System.out.println("formato de valor incrreto!");
        break;
      }
    }
    System.out.println("valor da contagem dos numeros inteiros = "+cont);
  }
}