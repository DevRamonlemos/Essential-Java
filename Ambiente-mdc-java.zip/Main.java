import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("insira o primeiro valor ");
    int valor1 = sc.nextInt();
    System.out.println("insira o segundo valor");
    int valor2 = sc.nextInt();
    int resto;
    while(valor2 != 0) {
        resto = valor1 % valor2;
        valor1 = valor2;
        valor2 = resto;
    }
    System.out.println("MDC = " + valor1);
  }
}