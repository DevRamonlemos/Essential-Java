import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("informe o valor de a");
    int a = input.nextInt();
    System.out.println("informe o valor de b");
    int b = input.nextInt();
    int aux;

    aux = a;
    a = b;
    b = aux;

    System.out.println("valor de a = " + a);
    System.out.println("valor de b = " + b);   
  }
}