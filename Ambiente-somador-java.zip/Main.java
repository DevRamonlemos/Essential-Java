import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    int soma=0;
    System.out.println("informe a quantidade de numeros para somar");
    int j= sc.nextInt();
    for(int i=0;i<j;i++){
      System.out.println("informe um numero para somar");
      int dados = sc.nextInt();
      soma = soma+dados;
    }
      System.out.println("resultado da soma = "+soma);
  }
}
